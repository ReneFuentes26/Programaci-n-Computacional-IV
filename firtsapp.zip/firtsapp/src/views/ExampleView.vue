<template>
  <example-component title="Programacion IV"> </example-component>
</template>

<script>
import ExampleComponent from "@/components/exampleComponent.vue";

export default {
  name: "example",
  components: {
    ExampleComponent,
  },
};
</script>
