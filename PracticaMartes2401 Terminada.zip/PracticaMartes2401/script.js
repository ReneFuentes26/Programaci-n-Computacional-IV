//Mostrar ocultar div
const hidebtn = document.querySelector('#hideElements')
const listDiv = document.querySelector('#list')

//Constantes para agregar elementos 
const addItemInput = document.querySelector('#addItem') //input:text
const addItemButton = document.querySelector('button#addItemButton')
const removeItem = document.querySelector('button#removeItem')

//agregar los eventos a al boton ocultar/mostrar
hidebtn.addEventListener('click', () => {
    if(listDiv.style.display == 'none'){
        listDiv.style.display = 'block'
        hidebtn.textContent = 'Ocultar'
    } else {
        listDiv.style.display = 'none'
        hidebtn.textContent = 'Mostrar'
    }
})


//Evaluar si el input esta vacio, no debe agregar el elmento 
addItemButton.addEventListener('click', () => {
    if(addItemInput.value.length ==0){
        window.alert("No se puede agregar un elemento sin nombre")
    } else{
    let list = document.querySelector('ul')
    let li = document.createElement('li')
    li.textContent = addItemInput.value 
    list.appendChild(li)
   addItemInput.value =''
}
})
//Centra al input

//Eliminar elementos 
//Funcion para obtener el indice del elemento en la lista
var list = document.getElementById('listItems'),
    items = list.getElementsByTagName('li')

const findIndex = (element) => {
    var len = items.length
    for(var i=0; i<len; i++){
        if(items[i]===element){
            return i
        }
    }
}

list.onclick = (e) => {
    let event = e || window.event
    src= event.target

    let myIndex = findIndex(src)
    index = myIndex
    //alert(myIndex)
    list.querySelectorAll('li').forEach(el=>el.classList.remove('alert','alert-danger'))
    items[myIndex].classList.add('alert','alert-success')
}

removeItem.addEventListener('click', ()=> {

    var result = confirm("Desea eliminar este elemento?");
    if(result==true)

    items[index].parentNode.removeChild(items[index])
})

//programar el boton
removeItem.addEventListener('click', () =>{
    items[index].parentNode.removeChild(items[index])
})