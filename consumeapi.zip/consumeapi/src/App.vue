<template>
  <nav>
    <router-link to="/">Home</router-link> |
    <router-link to="/countries">Countries</router-link> 
  </nav>
  <router-view />
</template>

