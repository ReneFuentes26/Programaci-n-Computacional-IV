<template>
    <filters />
    <countries />
</template>

<script>
import countries from '/src/components/countries/countries.vue';
import filter from '/src/components/countries/filters.vue';
export default({
    components:{
        countries,
        filter
    }
});


</script>
